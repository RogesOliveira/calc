# Calcular - Renda Fixada - Liberdade FInanceira

A Pen created on CodePen.io. Original URL: [https://codepen.io/Roges-oliveira/pen/KKLgBbE](https://codepen.io/Roges-oliveira/pen/KKLgBbE).

